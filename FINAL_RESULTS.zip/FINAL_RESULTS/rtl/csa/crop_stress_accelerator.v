module crop_stress_accelerator(
    input wire        clk,
    input wire        rst_n,
    input wire        enable,
    input wire        sample_valid,
    input wire [7:0]  moisture,
    input wire [7:0]  leaf_temp,
    input wire [7:0]  humidity,
    input wire [7:0]  air_temp,
    input wire [7:0]  light,
    
    input wire [7:0]  w_moisture,
    input wire [7:0]  w_leaftemp,
    input wire [7:0]  w_humidity,
    input wire [7:0]  w_airtemp,
    input wire [7:0]  w_light,
    
    input wire [3:0]  shift_factor,
    
    output wire [7:0] stress_score,
    output reg        score_valid
);

    wire [15:0] p_moisture;
    wire [15:0] p_leaftemp;
    wire [15:0] p_humidity;
    wire [15:0] p_airtemp;
    wire [15:0] p_light;

    weighted_sum ws_moisture (
        .sensor_value(moisture),
        .weight(w_moisture),
        .product(p_moisture)
    );

    weighted_sum ws_leaftemp (
        .sensor_value(leaf_temp),
        .weight(w_leaftemp),
        .product(p_leaftemp)
    );

    weighted_sum ws_humidity (
        .sensor_value(humidity),
        .weight(w_humidity),
        .product(p_humidity)
    );

    weighted_sum ws_airtemp (
        .sensor_value(air_temp),
        .weight(w_airtemp),
        .product(p_airtemp)
    );

    weighted_sum ws_light (
        .sensor_value(light),
        .weight(w_light),
        .product(p_light)
    );

    // Balanced combinational sum of weighted products.
    // Explicit widths preserve the full unsigned sum of five 16-bit products.
    wire [16:0] weighted_pair_01;
    wire [16:0] weighted_pair_23;
    wire [17:0] weighted_pair_0123;
    wire [18:0] weighted_sum_val_comb;

    assign weighted_pair_01   = {1'b0, p_moisture} + {1'b0, p_leaftemp};
    assign weighted_pair_23   = {1'b0, p_humidity} + {1'b0, p_airtemp};
    assign weighted_pair_0123 = {1'b0, weighted_pair_01} + {1'b0, weighted_pair_23};
    assign weighted_sum_val_comb = {1'b0, weighted_pair_0123} + {3'b0, p_light};

    // One-cycle pipeline register to break the adder-tree critical path
    reg [18:0] weighted_sum_val_reg;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            weighted_sum_val_reg <= 19'd0;
        else if (enable && sample_valid)
            weighted_sum_val_reg <= weighted_sum_val_comb;
    end

    reg [3:0] shift_factor_reg;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shift_factor_reg <= 4'd0;
            score_valid <= 1'b0;
        end else if (!enable) begin
            score_valid <= 1'b0;
        end else if (sample_valid) begin
            shift_factor_reg <= shift_factor;
            score_valid <= 1'b1;
        end
    end

    // Instantiate range-check/normalization block using the registered sum
    normalization_unit norm_inst (
        .weighted_sum_val(weighted_sum_val_reg),
        .shift_factor(shift_factor_reg),
        .stress_score(stress_score)
    );

endmodule
